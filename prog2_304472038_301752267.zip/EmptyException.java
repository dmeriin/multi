



public class EmptyException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 897646L;

	public EmptyException() {
		super();

	}
}
