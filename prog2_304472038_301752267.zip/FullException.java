



public class FullException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 897645L;

	public FullException() {
		super();

	}
}
